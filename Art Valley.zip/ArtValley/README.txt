ARTVALLEY:

1.Open the db file (our project file name)in Neatbeans
2. Run the sql file and check whether all the tables are created or not.
3. the connection code for our project is
con= "jdbc:sqlserver://localhost:1433;databaseName=ProjectDB;user=sa;password =123456"

4. Run the Netbeans file from SelectLogIn page 
(If you want to use the system as Artist or Customer then just register and log in our system. Otherwise if you're using the system as admin , give the username and password according (nishat,1234 or noholi,2345 or roza,3456)

Submitted by,

   Name                          Id

1.Noholi Islam Duti            190204008
2.Tasnuva Tamanna Nishat       190204014
3.Isfara Islam Roza            190204015